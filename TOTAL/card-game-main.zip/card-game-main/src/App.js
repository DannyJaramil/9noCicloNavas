import React from "react";

import { Home } from "./app/pages/Home";
import "./App.css";

function App() {
  return <Home />;
}

export default App;
